EV battery-aware ACC: code behind https://ev.sagniknath.in
=========================================================

Author: Sagnik Kumar Nath. Licence: MIT (see LICENSE). Repository: https://github.com/sagnikvolt/ev-mpc-acc
Archived release: https://doi.org/10.5281/zenodo.24186267  (this is where the data is; no data is included in this zip)

Files
-----
py/mpc_acc.py  (138 lines)
    The BMW i3 battery model, the conventional ACC simulator loop and the battery-aware MPC (cvxpy). The paper's file, unchanged.
py/baselines.py  (60 lines)
    The tuned ACC, the sliding-mode controller (SMC) and the policy wrapper used by the SAC controllers. The paper's file, unchanged.
py/safe_filter.py  (37 lines)
    The control-barrier safety filter used by the safe SAC controller. The paper's file, unchanged.
py/sac_env.py  (10 lines)
    Browser stub of the paper's sac_env.py: only the observation function and the trained-actor policy, copied verbatim; the gymnasium training environment is left out.
py/demo_core.py  (154 lines)
    Glue for the website: swaps the solver to Clarabel, runs the SAC actors as a numpy forward pass, and runs one controller on one window or uploaded trace.
py/demo_api.py  (34 lines)
    The JSON entry points that worker.js calls (list windows, run a window, run an upload, train a model).
code/matlab/verify_main.m  (114 lines)
    The independent MATLAB R2024b port of the ACC and the MPC with constant-speed preview, run on the 10 check windows; writes matlab_results.csv.
code/matlab/make_site_figs.m  (160 lines)
    Makes the bar chart and the window-1 trace figure of the Compare with MATLAB section (exportgraphics).
code/matlab/make_site_traces.m  (138 lines)
    Runs MATLAB on windows 1 to 10 and writes the per-window trace figures and trace files used by Run it in MATLAB mode.
worker.js  (59 lines)
    The Web Worker that loads Pyodide and the Python files and runs them off the main thread. Nothing leaves your device.

How to run
----------
Python (python/): Python 3.10 or newer with numpy, scipy, cvxpy and a QP solver (the paper used osqp, the website uses clarabel).
  The paper's pinned versions are in the repository's requirements.txt (numpy 2.2.6, scipy 1.15.3, cvxpy 1.7.5, osqp 1.1.3).
  mpc_acc.py, baselines.py and safe_filter.py are the paper's own files; put the folder on PYTHONPATH and import them.
  mpc_acc.py reads the battery parameter file results/bmw_i3_params_final.npy from the author's project folder; demo_core.py shows how the
  website rebuilds that file from the packaged CSV (derived_data/bmw_i3_params_final.csv in the Zenodo archive).
  The data files, the trained actors and the training and experiment scripts are in the Zenodo archive and the repository, not here.

MATLAB (matlab/): MATLAB R2024b with the Optimization Toolbox (quadprog solves each MPC step).
  Get matlab/verify/data (params.csv, win_1.csv ... win_10.csv, ref_acc.csv, ref_mpc.csv) from the repository or the Zenodo archive,
  put it next to verify_main.m, and run  verify_main  from that folder. It writes matlab_results.csv (Wh/km, minimum gap, jerk, final speed,
  solver failures for each of the 10 windows, ACC and MPC with constant-speed preview).

Scope: the MATLAB code covers the simulator, the conventional ACC and the MPC with constant-speed preview. It has no port of the SAC controllers,
the SMC, the map-aware MPC, V2V forecasting or the machine-learning models.

